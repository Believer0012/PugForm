const mongoose  = require("mongoose")


const Items= mongoose.model('Item',{
    name:String,
    description:String
});

// const Employee = mongoose.model('Employee',{
//     id:String,
//     uname:String,
//     age:Number,
//     designation:String,
//     salary:Number
// })

module.exports = {Items}